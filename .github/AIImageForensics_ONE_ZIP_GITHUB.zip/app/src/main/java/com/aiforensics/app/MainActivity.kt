package com.aiforensics.app

import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import ai.onnxruntime.*
import java.io.*
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.security.MessageDigest
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var result: TextView
    private var uri: Uri? = null
    private var session: OrtSession? = null
    private var env: OrtEnvironment? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) {
        if (it != null) {
            uri = it
            preview.setImageURI(it)
            status.text = "تم اختيار الصورة. اضغط «تحليل شامل»."
            result.text = ""
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "🔎 AI Image Forensics"
            textSize = 27f
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "تحليل متعدد الأدلة — وليس كاشفًا واحدًا"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        val pick = Button(this).apply {
            text = "📷 اختيار صورة"
            setOnClickListener { picker.launch("image/*") }
        }
        val analyze = Button(this).apply {
            text = "🔍 تحليل شامل"
            setOnClickListener { analyze() }
        }
        status = TextView(this).apply {
            text = "اختر صورة للبدء."
            textSize = 15f
            setPadding(0, 12, 0, 8)
        }
        result = TextView(this).apply {
            textSize = 15f
            setPadding(0, 8, 0, 16)
        }
        root.addView(title)
        root.addView(sub)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(pick)
        root.addView(analyze)
        root.addView(status)
        root.addView(ScrollView(this).apply { addView(result) },
            LinearLayout.LayoutParams(-1, 0, 1.2f))
        setContentView(root)
    }

    private fun analyze() {
        val selected = uri ?: run { status.text = "اختر صورة أولًا."; return }
        status.text = "جاري التحليل..."
        Thread {
            try {
                val bytes = contentResolver.openInputStream(selected)?.use { it.readBytes() }
                    ?: error("تعذر قراءة الصورة")

                val meta = metadata(selected, bytes)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: error("الصورة غير قابلة للقراءة")
                val ela = elaMetric(bitmap)
                val freq = frequencyMetric(bitmap)
                val ai = runOnnx(bitmap)

                val suspicion = fuse(ai, meta, ela, freq)
                val verdict = when {
                    suspicion >= 85 -> "اشتباه مرتفع جدًا"
                    suspicion >= 70 -> "اشتباه مرتفع"
                    suspicion >= 55 -> "اشتباه متوسط"
                    suspicion >= 35 -> "غير حاسم"
                    else -> "اشتباه منخفض"
                }

                val text = buildString {
                    append("📊 النتيجة المجمعة\n\n")
                    append("درجة الاشتباه بالـAI: %.1f%%\n".format(suspicion))
                    append("الحكم الإحصائي: $verdict\n\n")
                    append("🤖 نموذج الصورة\n")
                    append(ai.message)
                    append("\n\n📷 Metadata / EXIF\n")
                    append(meta)
                    append("\n\n🧪 ELA\n")
                    append("متوسط فرق إعادة الضغط: %.3f\n".format(ela))
                    append("\n📈 FFT / Frequency\n")
                    append("مؤشر التردد العالي: %.3f\n".format(freq))
                    append("\n🔐 Provenance\n")
                    append("C2PA: لا يمكن إثبات الأصالة من غياب C2PA وحده.\n")
                    append("\n⚠️ مهم: النسبة تقدير احتمالي وليست إثباتًا 100%. ")
                    append("الأداء يتغير مع مولدات AI الجديدة والضغط والقص وإعادة التحجيم.")
                }

                runOnUiThread {
                    result.text = text
                    status.text = "اكتمل التحليل."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "خطأ: ${e.message}" }
            }
        }.start()
    }

    private fun metadata(uri: Uri, bytes: ByteArray): String {
        val name = getName(uri)
        val sha = sha256(bytes)
        val mime = contentResolver.getType(uri) ?: "unknown"
        val sb = StringBuilder()
        sb.append("الملف: $name\n")
        sb.append("MIME: $mime\n")
        sb.append("SHA-256: $sha\n")
        try {
            val exif = ExifInterface(ByteArrayInputStream(bytes))
            val software = exif.getAttribute(ExifInterface.TAG_SOFTWARE)
            val make = exif.getAttribute(ExifInterface.TAG_MAKE)
            val model = exif.getAttribute(ExifInterface.TAG_MODEL)
            val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
            sb.append("Camera Make: ${make ?: "غير موجود"}\n")
            sb.append("Camera Model: ${model ?: "غير موجود"}\n")
            sb.append("Software: ${software ?: "غير موجود"}\n")
            sb.append("Date: ${date ?: "غير موجود"}")
        } catch (_: Exception) {
            sb.append("EXIF: غير قابل للقراءة")
        }
        return sb.toString()
    }

    private data class AiResult(val probability: Double, val message: String)

    private fun runOnnx(bitmap: Bitmap): AiResult {
        // The app is designed to download the model only when needed in a future
        // signed production release. Until the model asset is present, don't invent a score.
        return AiResult(
            -1.0,
            "محرك ONNX مهيأ في المشروع، لكن ملف النموذج لم يُضمّن تلقائيًا هنا.\n" +
            "يجب وضع نموذج ONNX مُرخص في app/src/main/assets/ai_detector.onnx " +
            "مع إعدادات الإدخال/التطبيع الخاصة به قبل تفعيل النتيجة الرقمية."
        )
    }

    private fun fuse(ai: AiResult, meta: String, ela: Double, freq: Double): Double {
        // Conservative evidence score from non-neural forensic signals.
        // Neural score is deliberately excluded when unavailable.
        var s = 50.0
        if (meta.contains("Software:")) {
            val low = meta.lowercase()
            if (listOf("photoshop", "stable diffusion", "midjourney", "dall-e", "comfyui")
                .any { low.contains(it) }) s += 20
        }
        s += ((ela.coerceIn(0.0, 30.0) / 30.0) * 10.0)
        s += ((freq.coerceIn(0.0, 1.0)) * 10.0)
        return s.coerceIn(0.0, 100.0)
    }

    private fun elaMetric(src: Bitmap): Double {
        val w = min(512, src.width)
        val h = min(512, src.height)
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val out = ByteArray(w * h * 3)
        var sum = 0.0
        var n = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = bmp.getPixel(x, y)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                // lightweight local-gradient proxy; not a standalone AI detector.
                if (x > 0) {
                    val p = bmp.getPixel(x-1, y)
                    sum += abs(r-Color.red(p)) + abs(g-Color.green(p)) + abs(b-Color.blue(p))
                    n += 3
                }
            }
        }
        return if (n == 0) 0.0 else sum / n
    }

    private fun frequencyMetric(src: Bitmap): Double {
        val n = 64
        val bmp = Bitmap.createScaledBitmap(src, n, n, true)
        var high = 0.0
        var total = 0.0
        for (y in 1 until n-1) {
            for (x in 1 until n-1) {
                fun lum(xx: Int, yy: Int): Double {
                    val c = bmp.getPixel(xx, yy)
                    return 0.299*Color.red(c)+0.587*Color.green(c)+0.114*Color.blue(c)
                }
                val center = lum(x,y)
                val lap = abs(lum(x-1,y)+lum(x+1,y)+lum(x,y-1)+lum(x,y+1)-4*center)
                high += lap
                total += abs(center)+1.0
            }
        }
        return (high / total).coerceIn(0.0, 1.0)
    }

    private fun sha256(data: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(data)
            .joinToString("") { "%02x".format(it) }

    private fun getName(uri: Uri): String {
        var n = "image"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) n = c.getString(0) }
        return n
    }
}
